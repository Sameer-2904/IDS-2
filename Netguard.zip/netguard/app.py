"""
Flask + SocketIO backend for the NetGuard IDS dashboard.

    python app.py                    # live capture (needs root/admin), else demo mode
    python app.py --demo             # force simulated traffic
    python app.py --iface eth0       # sniff one interface only
    python app.py --host 0.0.0.0     # expose on the LAN (no auth — be careful)
"""

import os
import sys
import argparse
import ipaddress
from collections import deque
import json

# Make `backend` importable regardless of the directory you start from
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
from flask_cors import CORS

from backend.detector import ThreatDetector, ALERTS_JSON
from backend.sniffer  import PacketSniffer

# ─── App Setup ────────────────────────────────────────────────────────────────

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)
CORS(app)

# "threading" mode: the sniffer runs in a normal Python thread, and events emitted
# from it reach the browser reliably (eventlet without monkey-patching does not).
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# ─── Core Objects ─────────────────────────────────────────────────────────────

def on_alert(alert: dict):
    """Called by detector whenever a new alert fires — push to all clients."""
    socketio.emit("new_alert", alert)

detector = ThreatDetector(alert_callback=on_alert)
sniffer  = PacketSniffer(detector, socketio=socketio, interface=os.environ.get("IDS_IFACE"))


def _ip_from_request():
    """Return a normalised IP string from the JSON body, or None if invalid."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return None
    try:
        return str(ipaddress.ip_address(str(data.get("ip", "")).strip()))
    except ValueError:
        return None


# ─── REST Endpoints ───────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("dashboard.html")


@app.route("/api/snapshot")
def snapshot():
    """Full state dump for initial page load."""
    return jsonify(detector.get_snapshot())


@app.route("/api/alerts")
def get_alerts():
    return jsonify(detector.get_snapshot()["alerts"])


@app.route("/api/suspicious")
def get_suspicious():
    return jsonify(detector.get_snapshot()["suspicious"])


@app.route("/api/block", methods=["POST"])
def block_ip():
    ip = _ip_from_request()
    if not ip:
        return jsonify({"error": "Please enter a valid IPv4/IPv6 address"}), 400
    msg = detector.block_ip(ip)
    socketio.emit("ip_blocked", {"ip": ip})
    return jsonify({"message": msg})


@app.route("/api/unblock", methods=["POST"])
def unblock_ip():
    ip = _ip_from_request()
    if not ip:
        return jsonify({"error": "Please enter a valid IPv4/IPv6 address"}), 400
    msg = detector.unblock_ip(ip)
    socketio.emit("ip_unblocked", {"ip": ip})
    return jsonify({"message": msg})


@app.route("/api/blocked")
def get_blocked():
    return jsonify(detector.get_snapshot()["blocked_ips"])


@app.route("/api/logs")
def get_logs():
    """Return the last 100 alerts from the JSON-lines log, newest first."""
    if not os.path.exists(ALERTS_JSON):
        return jsonify([])
    entries = deque(maxlen=100)
    with open(ALERTS_JSON, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return jsonify(list(entries)[::-1])


# ─── SocketIO Events ──────────────────────────────────────────────────────────

@socketio.on("connect")
def on_connect():
    emit("init", detector.get_snapshot())  # only to the client that just connected


# ─── Entry Point ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="NetGuard — Network IDS")
    parser.add_argument("--host",  default="127.0.0.1", help="bind address (default 127.0.0.1)")
    parser.add_argument("--port",  type=int, default=5000)
    parser.add_argument("--iface", default=None, help="network interface to sniff (default: all)")
    parser.add_argument("--demo",  action="store_true", help="use simulated traffic")
    args = parser.parse_args()

    if args.iface:
        sniffer.interface = args.iface
    if args.demo:
        sniffer.demo = True

    sniffer.start()

    shown_host = "localhost" if args.host in ("127.0.0.1", "0.0.0.0") else args.host
    print(f"\n  NetGuard IDS dashboard → http://{shown_host}:{args.port}\n")

    socketio.run(app, host=args.host, port=args.port, debug=False,
                 allow_unsafe_werkzeug=True)


if __name__ == "__main__":
    main()
