"""
Network Intrusion Detection Engine
Detects: Port Scanning, Brute-Force Login, DoS Attacks
"""

import os
import time
import json
import itertools
import logging
from collections import defaultdict, deque, Counter
from datetime import datetime
from threading import RLock

# ─── Paths (absolute, so it works no matter where you launch from) ────────────
BASE_DIR    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_DIR     = os.path.join(BASE_DIR, "logs")
LOG_FILE    = os.path.join(LOG_DIR, "ids.log")
ALERTS_JSON = os.path.join(LOG_DIR, "alerts.json")

# ─── Thresholds ────────────────────────────────────────────────────────────────
PORT_SCAN_THRESHOLD   = 15   # distinct ports within window → port scan
BRUTE_FORCE_THRESHOLD = 10   # SYN attempts to same login port → brute force
DOS_THRESHOLD         = 500  # packets per second from single IP → DoS
TIME_WINDOW           = 10   # seconds for rolling window analysis
CLEANUP_INTERVAL      = 60   # seconds between stale-entry cleanup

# Common login ports watched for brute-force
LOGIN_PORTS = {21, 22, 23, 25, 110, 143, 3306, 3389, 5432, 5900}


class ThreatDetector:
    """
    Stateful detector. Feed it packet metadata dicts via process(); alerts are
    stored, logged to disk and pushed to `alert_callback`.
    Thread-safe (single re-entrant lock).
    """

    def __init__(self, alert_callback=None):
        self.alert_callback = alert_callback  # called with alert dict on detection
        self._lock = RLock()

        os.makedirs(LOG_DIR, exist_ok=True)

        # Port-scan state: per source IP, a queue of (timestamp, port) plus a
        # Counter of ports currently inside the window → O(1) distinct-port count.
        self._scan_events: dict[str, deque]   = defaultdict(deque)
        self._scan_ports:  dict[str, Counter] = defaultdict(Counter)

        # Brute-force state: (src, login_port) → timestamps of SYN packets
        self._login_syns: dict[tuple, deque] = defaultdict(deque)

        # Per-IP packet timestamps for DoS detection (1-second window)
        self._pkt_times: dict[str, deque] = defaultdict(deque)

        # Already-alerted IPs per attack type (reset every CLEANUP_INTERVAL)
        self._alerted: dict[str, set] = defaultdict(set)

        # Blocked IPs (manual)
        self.blocked_ips: set[str] = set()

        self._last_cleanup = time.time()
        self._alert_ids = itertools.count(int(time.time() * 1000))

        # Counters exposed to dashboard
        self.stats = {
            "total_packets": 0,
            "tcp_packets":   0,
            "udp_packets":   0,
            "icmp_packets":  0,
            "alerts_total":  0,
        }

        # Recent alerts ring-buffer (latest 200, newest first)
        self.alerts: deque = deque(maxlen=200)

        # Suspicious IPs  { ip: {attack_type, count, last_seen} }
        self.suspicious: dict[str, dict] = {}

        # Dedicated logger (does not hijack the root logger like basicConfig did)
        self.logger = logging.getLogger("IDS")
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False
        if not self.logger.handlers:
            handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
            handler.setFormatter(
                logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
            )
            self.logger.addHandler(handler)

    # ─── Public API ────────────────────────────────────────────────────────────

    def process(self, pkt_meta: dict) -> None:
        """Accept a packet metadata dict and run detection logic."""
        with self._lock:
            self._update_stats(pkt_meta)
            now = pkt_meta.get("ts") or time.time()

            src = pkt_meta.get("src")
            if not src or src in self.blocked_ips:
                return

            proto    = pkt_meta.get("proto", "")
            dst_port = pkt_meta.get("dst_port")
            flags    = pkt_meta.get("flags", "") or ""

            # Only packets WITHOUT the ACK bit are connection attempts / probes
            # (SYN, or stealth FIN/NULL/Xmas scans). Everything else is reply or
            # established-session traffic and must not count as scanning —
            # otherwise a busy server replying to clients looks like a "scanner".
            if proto == "TCP" and dst_port and "A" not in flags:
                is_syn = "S" in flags
                self._track_port(src, dst_port, now, is_syn)
                self._check_port_scan(src)
                if is_syn:
                    self._check_brute_force(src, dst_port)

            self._track_dos(src, now)
            self._check_dos(src)

            if now - self._last_cleanup > CLEANUP_INTERVAL:
                self._cleanup(now)

    def block_ip(self, ip: str) -> str:
        with self._lock:
            self.blocked_ips.add(ip)
            self.logger.warning("BLOCKED %s", ip)
            return f"{ip} blocked"

    def unblock_ip(self, ip: str) -> str:
        with self._lock:
            self.blocked_ips.discard(ip)
            self.logger.info("UNBLOCKED %s", ip)
            return f"{ip} unblocked"

    def get_stats(self) -> dict:
        with self._lock:
            return dict(self.stats)

    def get_snapshot(self) -> dict:
        with self._lock:
            return {
                "stats":       dict(self.stats),
                "alerts":      list(self.alerts),
                "suspicious":  {ip: dict(v) for ip, v in self.suspicious.items()},
                "blocked_ips": sorted(self.blocked_ips),
            }

    # ─── Internal helpers ──────────────────────────────────────────────────────

    def _update_stats(self, pkt_meta: dict) -> None:
        self.stats["total_packets"] += 1
        proto = pkt_meta.get("proto", "")
        if proto == "TCP":
            self.stats["tcp_packets"] += 1
        elif proto == "UDP":
            self.stats["udp_packets"] += 1
        elif proto == "ICMP":
            self.stats["icmp_packets"] += 1

    # -- port scan / brute force ------------------------------------------------

    def _track_port(self, src: str, port: int, now: float, is_syn: bool) -> None:
        events, ports = self._scan_events[src], self._scan_ports[src]
        events.append((now, port))
        ports[port] += 1
        while events and now - events[0][0] > TIME_WINDOW:
            _, old_port = events.popleft()
            ports[old_port] -= 1
            if ports[old_port] <= 0:
                del ports[old_port]

        if is_syn and port in LOGIN_PORTS:
            q = self._login_syns[(src, port)]
            q.append(now)
            while q and now - q[0] > TIME_WINDOW:
                q.popleft()

    def _check_port_scan(self, src: str) -> None:
        distinct = len(self._scan_ports[src])
        if distinct >= PORT_SCAN_THRESHOLD and src not in self._alerted["port_scan"]:
            self._alerted["port_scan"].add(src)
            self._raise_alert(src, "Port Scan",
                              f"Hit {distinct} distinct ports in {TIME_WINDOW}s", "HIGH")

    def _check_brute_force(self, src: str, port: int) -> None:
        if port not in LOGIN_PORTS:
            return
        recent = len(self._login_syns[(src, port)])
        key = f"brute_{port}"
        if recent >= BRUTE_FORCE_THRESHOLD and src not in self._alerted[key]:
            self._alerted[key].add(src)
            self._raise_alert(src, "Brute Force",
                              f"{recent} login attempts on port {port} in {TIME_WINDOW}s", "HIGH")

    # -- DoS ---------------------------------------------------------------------

    def _track_dos(self, src: str, now: float) -> None:
        q = self._pkt_times[src]
        q.append(now)
        while q and now - q[0] > 1.0:  # 1-second sliding window
            q.popleft()

    def _check_dos(self, src: str) -> None:
        rate = len(self._pkt_times[src])
        if rate >= DOS_THRESHOLD and src not in self._alerted["dos"]:
            self._alerted["dos"].add(src)
            self._raise_alert(src, "DoS Attack", f"{rate} packets/sec from {src}", "CRITICAL")

    # -- alerting ----------------------------------------------------------------

    def _raise_alert(self, src: str, attack_type: str, detail: str, severity: str) -> None:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        alert = {
            "id":          next(self._alert_ids),
            "timestamp":   ts,
            "src_ip":      src,
            "attack_type": attack_type,
            "detail":      detail,
            "severity":    severity,
        }
        self.alerts.appendleft(alert)
        self.stats["alerts_total"] += 1

        # Update suspicious registry
        entry = self.suspicious.setdefault(
            src, {"attack_type": attack_type, "count": 0, "last_seen": ts}
        )
        entry["count"] += 1
        entry["last_seen"] = ts
        entry["attack_type"] = attack_type

        self.logger.warning("[%s] %s from %s — %s", severity, attack_type, src, detail)

        # Persist to JSON-lines log (a disk error must never kill the sniffer)
        try:
            with open(ALERTS_JSON, "a", encoding="utf-8") as f:
                f.write(json.dumps(alert) + "\n")
        except OSError as e:
            self.logger.error("Could not write alerts.json: %s", e)

        # Push to dashboard (a socket error must never kill the sniffer either)
        if self.alert_callback:
            try:
                self.alert_callback(alert)
            except Exception as e:  # noqa: BLE001
                self.logger.error("alert_callback failed: %s", e)

    def _cleanup(self, now: float) -> None:
        stale = [ip for ip, q in self._pkt_times.items()
                 if not q or now - q[-1] > CLEANUP_INTERVAL]
        for ip in stale:
            self._pkt_times.pop(ip, None)
            self._scan_events.pop(ip, None)
            self._scan_ports.pop(ip, None)
        stale_set = set(stale)
        for key in [k for k in self._login_syns if k[0] in stale_set]:
            del self._login_syns[key]
        self._alerted.clear()
        self._last_cleanup = now
