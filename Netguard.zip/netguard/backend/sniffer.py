"""
Packet Sniffer — wraps Scapy to feed ThreatDetector.
Runs in a background daemon thread. If live capture is impossible (no root,
no Npcap/libpcap, bad interface …) it falls back to DEMO mode automatically.
"""

import os
import time
import random
import itertools
import threading

try:
    from scapy.all import sniff, IP, IPv6, TCP, UDP, ICMP
    SCAPY_AVAILABLE = True
except Exception:  # ImportError, or Scapy failing to initialise on this OS
    SCAPY_AVAILABLE = False

STATS_EMIT_INTERVAL = 1.0  # seconds between "stats_update" pushes to the dashboard


class PacketSniffer:
    def __init__(self, detector, socketio=None, interface: str = None, demo: bool = False):
        self.detector  = detector
        self.socketio  = socketio
        self.interface = interface  # None → sniff all interfaces
        self.demo      = demo or os.environ.get("IDS_DEMO") == "1"
        self._thread   = None
        self._running  = False
        self._last_emit = 0.0

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(target=self._sniff_loop, daemon=True, name="sniffer")
        self._thread.start()

    def stop(self):
        self._running = False

    # ─── Internal ──────────────────────────────────────────────────────────────

    def _sniff_loop(self):
        if self.demo:
            print("[IDS] DEMO mode (forced) — simulated traffic.")
            self._demo_loop()
            return

        if not SCAPY_AVAILABLE:
            print("[IDS] Scapy not available — running in DEMO mode with simulated traffic.")
            self._demo_loop()
            return

        try:
            print(f"[IDS] Live capture on {self.interface or 'all interfaces'} …")
            sniff(
                iface       = self.interface,
                prn         = self._handle_packet,
                store       = False,
                stop_filter = lambda _: not self._running,
            )
        except PermissionError:
            print("[IDS] Need root/admin to capture packets — switching to DEMO mode.")
            self._demo_loop()
        except Exception as e:  # missing Npcap/libpcap, invalid interface, …
            print(f"[IDS] Live capture failed ({type(e).__name__}: {e}) — switching to DEMO mode.")
            self._demo_loop()

    def _handle_packet(self, pkt):
        try:
            if IP in pkt:
                src, dst = pkt[IP].src, pkt[IP].dst
            elif IPv6 in pkt:
                src, dst = pkt[IPv6].src, pkt[IPv6].dst
            else:
                return

            meta = {"ts": time.time(), "src": src, "dst": dst}
            if TCP in pkt:
                meta.update(proto="TCP", src_port=pkt[TCP].sport, dst_port=pkt[TCP].dport,
                            flags=str(pkt[TCP].flags))
            elif UDP in pkt:
                meta.update(proto="UDP", src_port=pkt[UDP].sport, dst_port=pkt[UDP].dport)
            elif ICMP in pkt:
                meta["proto"] = "ICMP"
            else:
                meta["proto"] = "OTHER"

            self.detector.process(meta)
            self._maybe_emit_stats()
        except Exception as e:  # one malformed packet must never stop the capture
            print(f"[IDS] packet skipped ({type(e).__name__}: {e})")

    def _maybe_emit_stats(self, force: bool = False):
        """Throttled: at most one push per STATS_EMIT_INTERVAL, not one per packet."""
        now = time.monotonic()
        if force or now - self._last_emit >= STATS_EMIT_INTERVAL:
            self._last_emit = now
            if self.socketio:
                self.socketio.emit("stats_update", self.detector.get_stats())

    # ─── Demo mode (no root / no Scapy) ───────────────────────────────────────

    def _demo_loop(self):
        """
        Simulates realistic traffic including attack patterns so the dashboard
        can be demonstrated without a live network capture.
        """
        benign_ips  = ["192.168.1.10", "192.168.1.20", "10.0.0.5"]
        attack_ips  = ["45.33.32.156", "185.220.101.1", "198.51.100.42", "203.0.113.77"]
        login_ports = [22, 3389, 3306, 21, 5900]

        for tick in itertools.count():
            if not self._running:
                break

            now = time.time()

            # Normal traffic burst
            for _ in range(random.randint(5, 15)):
                self.detector.process({
                    "ts": now, "src": random.choice(benign_ips), "dst": "10.0.0.1",
                    "proto": random.choice(["TCP", "UDP"]),
                    "src_port": random.randint(1024, 65535),
                    "dst_port": random.choice([80, 443, 8080]),
                    "flags": "A",
                })

            # ── Simulate Port Scan every ~20 s ────────────────────────────────
            if tick % 20 == 5:
                attacker = random.choice(attack_ips)
                for port in random.sample(range(1, 10000), 20):
                    self.detector.process({
                        "ts": now, "src": attacker, "dst": "10.0.0.1",
                        "proto": "TCP", "src_port": random.randint(40000, 60000),
                        "dst_port": port, "flags": "S",
                    })

            # ── Simulate Brute-Force every ~30 s ──────────────────────────────
            if tick % 30 == 10:
                attacker = random.choice(attack_ips)
                port = random.choice(login_ports)
                for _ in range(15):
                    self.detector.process({
                        "ts": now, "src": attacker, "dst": "10.0.0.1",
                        "proto": "TCP", "src_port": random.randint(40000, 60000),
                        "dst_port": port, "flags": "S",
                    })

            # ── Simulate DoS burst every ~50 s ────────────────────────────────
            if tick % 50 == 25:
                attacker = random.choice(attack_ips)
                for _ in range(600):
                    self.detector.process({
                        "ts": now, "src": attacker, "dst": "10.0.0.1",
                        "proto": "UDP", "src_port": random.randint(1024, 65535),
                        "dst_port": 80,
                    })

            self._maybe_emit_stats(force=True)
            time.sleep(1)
